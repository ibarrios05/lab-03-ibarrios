import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

public class Starter {

    public static void main(String[] args){
//        File f = new File("data.txt");
//
//        //If the file is just in your project folder, then this fine
//        File inProject = new File("data0.txt");
//
////Gets the absolute path of the user's home directory
//        String home = System.getProperty("user.home");
//        Path path = Paths.get(home, "Documents", "JavaProjects", "data.txt");
//
////Convert the path to a file
//        File data1File = path.toFile();
////For fun print out the path
//        System.out.println(path.toString());
//
////Gets the absolute path of the current "working" directory
//        String working = System.getProperty("user.dir");
//        Path pathWorking = Paths.get(working,"dataDir","dataSub", "data2.txt");
//        System.out.println(pathWorking.toString());
//
//        File data2File = pathWorking.toFile();
//
////If you don't put an absolute header, it's assumed to be relative
////Same as "working" but less explicit.
//        Path pathRelative = Paths.get("dataDir","dataSub", "data3.txt");
//        System.out.println(pathRelative.toString());
//        File data3File = pathWorking.toFile();
//
////Can also be used to get directories
//        Path pathDir= Paths.get("dataDir","dataSub");
//        boolean isDirExist = Files.exists(pathDir);
//        System.out.println(isDirExist);

//        //Creating a path just for your records.
//        //This example REQUIRES you have data.txt in your project directory
//        Path noPath = Paths.get("data.txt");
//        File simpleData = noPath.toFile();
//        //The construction of fr and br may fail, gotta
//        //make them null first so we can tell failure
//        FileReader fr = null;
//        BufferedReader br = null;
//        try{
//            //This can throw file not found exception
//            fr = new FileReader(simpleData);
//            br = new BufferedReader(fr);
//            //Null when we're done
//            String lineOData = br.readLine();
//            while(lineOData!=null){
//                System.out.println("data "+lineOData);
//                lineOData = br.readLine();
//            }
//        } catch (IOException ex){
//            //Print to the error stream
//            //IOException ex will contain attempted file name
//            System.err.println("ERROR accessing :"+ex.getMessage());
//        } finally {
//            //Ok, we're done let's close this down.
//            try {
//                //br may have failed to init, check before closing
//                if(br != null){
//                    br.close();
//                }
//            } catch (IOException ex){
//                //We couldn't close the file?
//                //Ok, we're screwed bail.
//                ex.printStackTrace();
//                //Non-zero means we failed
//                System.exit(-1);
//            }
//        }


//        //This overwrites the file
//        Path noPathWrite = Paths.get("dataWrite.txt");
//        File simpleWriter = noPathWrite.toFile();
//        PrintWriter pw = null;
//        FileWriter fw = null;
//        BufferedWriter bw = null;
//        try {
//            fw = new FileWriter(simpleWriter);
//            bw = new BufferedWriter(fw);
//            pw = new PrintWriter(bw);
//
//            pw.print("Something");
//            pw.println(" now write with a new line");
//            pw.println("And another string");
//
//        } catch (IOException ex){
//            System.err.println("Error with file :"+ex.getMessage());
//        } finally {
//            if(pw!=null){
//                //This is when you actually WRITE
//                pw.close();
//            }
//        }


//        String data = "a,b,c,d";
//        String[] brokenData = data.split(",");
//        for(int i=0;i<brokenData.length;i++){
//            System.out.println("i :"+i+" value "+brokenData[i]);
//        }


        Scanner scan = new Scanner(System.in);
        System.out.println("please enter a FIPS ID or a County,State (Enter New York City,New York to see New york data)");
        String FIPSidOrCityState = scan.nextLine();
        String FIPSid = null;
        String city = null;
        String state = null;
        FIPSidOrCityState.trim();
        try {
            Integer.parseInt(FIPSidOrCityState);
            FIPSid = FIPSidOrCityState;
        }catch (NumberFormatException e){
            String[] cityState = FIPSidOrCityState.split(",");
            city = cityState[0].trim();
            state = cityState[1].trim();

        }
        scan.close();

        Path noPath = Paths.get("us-counties.csv");
        File simpleData = noPath.toFile();
        //The construction of fr and br may fail, gotta
        //make them null first so we can tell failure
        FileReader fr = null;
        BufferedReader br = null;

        ArrayList<Integer> casesInAnyCounty = new ArrayList<Integer>();
        ArrayList<Integer> deathsInAnyCounty = new ArrayList<Integer>();
        try{
            //This can throw file not found exception
            fr = new FileReader(simpleData);
            br = new BufferedReader(fr);
            //Null when we're done
            String lineOData = br.readLine();
            while(lineOData!=null){
                String[] brokenLine = lineOData.split(",");

                //FIPS is the Unique ID for each county in America.
                final int indexOfFIPSinEachLine = 3;

                if( (FIPSid!=null && brokenLine[indexOfFIPSinEachLine].equalsIgnoreCase(FIPSid))
                || (city!=null && state != null && brokenLine[1].equalsIgnoreCase(city) && brokenLine[2].equalsIgnoreCase(state))){
                    final int indexOfCases = 4;
                    final int indexOfDeaths = 5;
                    final int indexOfDate = 0;
                    System.out.println("On "+brokenLine[indexOfDate]+", there were "+brokenLine[indexOfCases]+" cases and "+brokenLine[indexOfDeaths]+" deaths");

                    Integer oneDayOfCasesInOneCounty = Integer.parseInt(brokenLine[indexOfCases]);
                    casesInAnyCounty.add(oneDayOfCasesInOneCounty);

                    Integer oneDayOfDeathsInOneCounty = Integer.parseInt(brokenLine[indexOfDeaths]);
                    deathsInAnyCounty.add(oneDayOfDeathsInOneCounty);
                }
                lineOData = br.readLine();
            }
        } catch (IOException ex){
            //Print to the error stream
            //IOException ex will contain attempted file name
            System.err.println("ERROR accessing :"+ex.getMessage());
        } finally {
            //Ok, we're done let's close this down.
            try {
                //br may have failed to init, check before closing
                if(br != null){
                    br.close();
                }
            } catch (IOException ex){
                //We couldn't close the file?
                //Ok, we're screwed bail.
                ex.printStackTrace();
                //Non-zero means we failed
                System.exit(-1);
            }
        }
        if(casesInAnyCounty.size()==0){
            System.out.println("Error, could not display");
            return;
        }
        int[] casesArray= new int[casesInAnyCounty.size()];
        for(int i =0;i<casesArray.length;i++){
            casesArray[i] = casesInAnyCounty.get(i);
        }
        Magic.drawGraph(casesArray);

        if(deathsInAnyCounty.size()==0){
            System.out.println("Error, could not display");
            return;
        }
        int[] arrayOfDeath= new int[deathsInAnyCounty.size()];
        for(int i =0;i<arrayOfDeath.length;i++){
            arrayOfDeath[i] = deathsInAnyCounty.get(i);
        }
        Magic.drawGraph(arrayOfDeath);

    }
}
